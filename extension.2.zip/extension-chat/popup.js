const SUPABASE_URL = "https://nlgzunlagcdgsbkzeiin.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5sZ3p1bmxhZ2NkZ3Nia3plaWluIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc2MDQyNzksImV4cCI6MjA4MzE4MDI3OX0.4sSfmztjJJkfHaIOBOK6Pv-27QWSpM2B-lxg0b3XC7U";
const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

document.addEventListener('DOMContentLoaded', async () => {
    const loginBtn = document.getElementById('login-btn');
    const loginBox = document.getElementById('login-box');
    const chatBox = document.getElementById('chat-box');
    const userInput = document.getElementById('user-input');
    const msgBox = document.getElementById('messages');

    let m13Id = localStorage.getItem('m13_id') || ('M13-' + Math.random().toString(36).substr(2, 9));
    localStorage.setItem('m13_id', m13Id);

    let monPseudo = localStorage.getItem('m13_pseudo');
    let lastMsgId = 0;

    async function checkBan() {
        const { data: pBan } = await supabaseClient.from('ban').select('*').eq('m13_id', m13Id).maybeSingle();
        if (pBan) {
            document.body.innerHTML = "<h1 style='color:red; text-align:center; padding:20px;'>ACCÈS RÉVOQUÉ</h1>";
            return true;
        }
        return false;
    }

    if (await checkBan()) return;
    if (monPseudo) activerChat();

    loginBtn.addEventListener('click', () => {
        const u = document.getElementById('username').value.trim();
        const p = document.getElementById('password').value;
        if (u.toLowerCase() === 'siroxtag' && p === 'SM13') monPseudo = "Siroxtag";
        else if (u.toLowerCase() === 'samri' && p === 'Sally') monPseudo = "Samri";
        else monPseudo = u;
        localStorage.setItem('m13_pseudo', monPseudo);
        activerChat();
    });

    function activerChat() {
        loginBox.style.display = 'none';
        chatBox.style.display = 'block';
        chargerMessages(true);
        // On vérifie les nouveaux messages toutes le 2 secondes
        setInterval(() => chargerMessages(false), 2000); 
    }

    async function chargerMessages(forceScroll) {
        // On récupère uniquement ce qui est strictement PLUS GRAND que le dernier ID affiché
        const { data: msgs } = await supabaseClient
            .from('messages_m13')
            .select('*')
            .gt('id', lastMsgId)
            .order('id', { ascending: true });

        if (msgs && msgs.length > 0) {
            const isAtBottom = msgBox.scrollHeight - msgBox.clientHeight <= msgBox.scrollTop + 50;
            
            for (const m of msgs) {
                // Double vérification : si l'ID est déjà traité, on passe au suivant
                if (m.id <= lastMsgId) continue;
                
                await afficherMessage(m.pseudo, m.message);
                lastMsgId = m.id;
            }

            if (isAtBottom || forceScroll) {
                msgBox.scrollTo({ top: msgBox.scrollHeight, behavior: 'smooth' });
            }
        }
    }

    userInput.addEventListener('keypress', async (e) => {
        if (e.key === 'Enter' && userInput.value.trim() !== "") {
            const text = userInput.value.trim();
            userInput.value = "";

            if (text.startsWith('/')) {
                const cmd = text.split(" ")[0].toLowerCase();
                const { data: userRole } = await supabaseClient.from('verif').select('role').eq('pseudo', monPseudo).maybeSingle();
                if (cmd === "/clean" && (userRole?.role === 'owner' || userRole?.role === 'op')) {
                    await supabaseClient.from('messages_m13').delete().neq('id', 0);
                    msgBox.innerHTML = "";
                    lastMsgId = 0;
                }
                return;
            }

            // On envoie simplement. chargerMessages() s'occupera de l'afficher 
            // dès que Supabase l'aura enregistré. C'est le secret pour éviter les doublons.
            await supabaseClient.from('messages_m13').insert([{ 
                pseudo: monPseudo, 
                message: text 
            }]);
        }
    });

    async function afficherMessage(p, m) {
        const d = document.createElement('div');
        d.className = "msg";
        const { data: status } = await supabaseClient.from('verif').select('role').eq('pseudo', p).maybeSingle();
        
        let badges = "", color = "#aaa";
        if (status) {
            if (status.role === 'owner') { 
                color = "#0f0"; 
                badges = ` <img src="verified_ico.png" width="14"> <img src="crown_ico.png" width="14">`; 
            } else if (status.role === 'op') { 
                color = "#0af"; 
                badges = ` <img src="verified_ico.png" width="14">`; 
            }
        }
        
        d.innerHTML = `<b style="color:${color}">${p}${badges}:</b> <span style="color:#eee">${m}</span>`;
        msgBox.appendChild(d);
    }
});