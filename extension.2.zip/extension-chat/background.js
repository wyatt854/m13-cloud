try {
    importScripts('supabase.js');
} catch (e) {
    console.error("Erreur SDK Supabase :", e);
}

const SUPABASE_URL = "https://nlgzunlagcdgsbkzeiin.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5sZ3p1bmxhZ2NkZ3Nia3plaWluIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc2MDQyNzksImV4cCI6MjA4MzE4MDI3OX0.4sSfmztjJJkfHaIOBOK6Pv-27QWSpM2B-lxg0b3XC7U";

const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

// Écoute universelle sur la table messages_m13
supabaseClient
  .channel('public:messages_m13')
  .on('postgres_changes', { event: '*', schema: 'public', table: 'messages_m13' }, payload => {
    
    // CAS 1 : Nouveau message (INSERT)
    if (payload.eventType === 'INSERT') {
        chrome.runtime.sendMessage({ 
            type: "NEW_MESSAGE", 
            data: payload.new 
        }).catch(() => {});

        // Petite notification système
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icon.png',
            title: `M13 - ${payload.new.pseudo}`,
            message: payload.new.message,
            priority: 2
        });
    } 
    
    // CAS 2 : Nettoyage de la table (DELETE)
    // C'est ici que le background dit au popup de tout effacer
    else if (payload.eventType === 'DELETE' || (payload.eventType === 'UPDATE' && !payload.new)) {
        chrome.runtime.sendMessage({ 
            type: "CHAT_CLEANED" 
        }).catch(() => {});
    }
  })
  .subscribe();

// Écoute externe pour le site Cloud GitHub
chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
    if (request.action === "CHECK_UPDATE_DONE") {
        sendResponse({ success: true });
    }
});