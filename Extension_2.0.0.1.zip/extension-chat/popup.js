/**
 * PROJECT M13 - OMEGA EDITION v2.0.0.1
 * Développeur : Wyatt (Siroxtag)
 * Système de Chat Ultra-sécurisé avec Gestion Admin Avancée
 */

const SUPABASE_URL = "https://nlgzunlagcdgsbkzeiin.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5sZ3p1bmxhZ2NkZ3Nia3plaWluIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc2MDQyNzksImV4cCI6MjA4MzE4MDI3OX0.4sSfmztjJJkfHaIOBOK6Pv-27QWSpM2B-lxg0b3XC7U";
const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

const CURRENT_VERSION = "2.0.0.1";
const AUDIO_URL = 'https://bitsrc.imgix.net/7fb953930b5e28328148b598d9c22e4d.wav';
const notifSound = new Audio(AUDIO_URL);

// --- ÉTATS GLOBAUX DU NOYAU ---
let lastMsgId = 0;
let isFetching = false;
let monPseudo = localStorage.getItem('m13_pseudo');
let m13Id = localStorage.getItem('m13_id') || ('M13-' + Math.random().toString(36).substr(2, 9));
localStorage.setItem('m13_id', m13Id);
let lastActivity = Date.now();

document.addEventListener('DOMContentLoaded', async () => {
    const loginBox = document.getElementById('login-box');
    const chatBox = document.getElementById('chat-box');
    const msgBox = document.getElementById('messages');
    const userInput = document.getElementById('user-input');
    const loginBtn = document.getElementById('login-btn');

    // --- 1. INTERFACE DE CHARGEMENT HAUTE DÉFINITION ---
    const loader = document.createElement('div');
    loader.id = "m13-mega-loader";
    loader.style = "position:fixed;top:0;left:0;width:100%;height:100%;z-index:9999;background:#050505;display:none;flex-direction:column;align-items:center;justify-content:center;font-family:monospace;";
    loader.innerHTML = `
        <div style="width: 300px; text-align: center;">
            <div id="m13-logo" style="color:#0af; font-size:24px; font-weight:bold; margin-bottom:20px; text-shadow:0 0 15px #0af;">[ PROJECT M13 ]</div>
            <div style="width:100%; background:#111; height:6px; border-radius:10px; overflow:hidden; border:1px solid #222;">
                <div id="m13-bar" style="width:0%; height:100%; background:linear-gradient(90deg,#004cff,#0af); transition:width 0.3s ease;"></div>
            </div>
            <div id="m13-status" style="color:#444; font-size:9px; margin-top:10px; text-transform:uppercase; letter-spacing:2px;">Initializing Core...</div>
            <div id="m13-pct" style="color:#0af; font-size:12px; margin-top:5px;">0%</div>
        </div>`;
    document.body.appendChild(loader);

    function updateLoader(pct, txt) {
        document.getElementById('m13-bar').style.width = pct + "%";
        document.getElementById('m13-status').innerText = txt;
        document.getElementById('m13-pct').innerText = pct + "%";
    }

    // --- 2. MODULE DE COMMANDES ADMIN (CLEAN, OP, BAN, UNBAN) ---
    async function executeAdminCommand(raw) {
        const args = raw.split(" ");
        const cmd = args[0].toLowerCase();
        const target = args[1];

        const { data: userRole } = await supabaseClient.from('verif').select('role').eq('pseudo', monPseudo).maybeSingle();
        const isAdmin = userRole?.role === 'owner';
        const isMod = isAdmin || userRole?.role === 'op';

        if (!isMod) { console.warn("Unauthorized command attempt."); return; }

        switch (cmd) {
            case '/clean':
                await supabaseClient.from('messages_m13').delete().neq('id', 0);
                msgBox.innerHTML = "<p style='color:orange; font-size:10px;'>[SYSTEM] Chat nettoyé par l'admin.</p>";
                lastMsgId = 0;
                break;
            case '/op':
                if (isAdmin) await supabaseClient.from('verif').upsert([{ pseudo: target, role: 'op' }]);
                break;
            case '/deop':
                if (isAdmin) await supabaseClient.from('verif').delete().eq('pseudo', target);
                break;
            case '/ban':
                await supabaseClient.from('ban').insert([{ m13_id: target, pseudo: target }]);
                break;
            case '/unban':
                await supabaseClient.from('ban').delete().eq('pseudo', target);
                break;
            case '/warn':
                await supabaseClient.from('messages_m13').insert([{ pseudo: 'Server', message: `⚠️ AVERTISSEMENT : ${target}, respectez les règles.` }]);
                break;
        }
    }

    // --- 3. GESTION DES MISES À JOUR FORCÉES ---
    async function checkUpdate() {
        try {
            const { data } = await supabaseClient.from('update').select('version').eq('id', 1).maybeSingle();
            if (data && data.version !== CURRENT_VERSION) {
                const link = `https://cloud.projectm13.xyz/extension_${data.version}.zip`;
                document.body.innerHTML = `
                    <div style="background:#000;color:white;height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;font-family:sans-serif;">
                        <h1 style="color:#ff3333;">UPDATE REQUIS (${data.version})</h1>
                        <p style="margin:20px;">Votre version ${CURRENT_VERSION} est obsolète.</p>
                        <a href="${link}" target="_blank" style="background:#0af;color:white;padding:15px 30px;text-decoration:none;border-radius:5px;font-weight:bold;box-shadow:0 0 20px rgba(0,170,255,0.4);">TÉLÉCHARGER LE ZIP</a>
                        <p style="margin-top:40px;color:#222;">cloud.projectm13.xyz</p>
                    </div>`;
                return true;
            }
        } catch (e) { console.error("Update sync failed."); }
        return false;
    }

    // --- 4. RÉCUPÉRATION ET RENDU DES MESSAGES ---
    async function fetchMessages(forceScroll = false) {
        if (isFetching || (Date.now() - lastActivity > 300000)) return; // Idle après 5 min
        isFetching = true;
        try {
            const { data: msgs } = await supabaseClient.from('messages_m13').select('*').gt('id', lastMsgId).order('id', { ascending: true });
            if (msgs && msgs.length > 0) {
                const isBottom = msgBox.scrollHeight - msgBox.clientHeight <= msgBox.scrollTop + 80;
                for (const m of msgs) {
                    if (m.id > lastMsgId) {
                        await buildMessageNode(m.pseudo, m.message);
                        lastMsgId = m.id;
                        if (m.pseudo !== monPseudo && !forceScroll) notifSound.play().catch(() => {});
                    }
                }
                if (isBottom || forceScroll) msgBox.scrollTo({ top: msgBox.scrollHeight, behavior: 'smooth' });
            }
        } finally { isFetching = false; }
    }

    async function buildMessageNode(author, text) {
        const el = document.createElement('div');
        el.className = "m13-msg";
        el.style = "margin-bottom:8px; animation: slideIn 0.2s ease; font-size:13px; border-left: 2px solid transparent; padding-left:5px;";
        
        // Système de mention
        if (text.includes(monPseudo)) el.style.background = "rgba(255, 215, 0, 0.1)";

        const { data: roleData } = await supabaseClient.from('verif').select('role').eq('pseudo', author).maybeSingle();
        let b = "", c = "#888";

        if (roleData?.role === 'owner') { c = "#00ff44"; b = ` <img src="verified_ico.png" width="12"> <img src="crown_ico.png" width="12">`; }
        else if (roleData?.role === 'op') { c = "#00aaff"; b = ` <img src="verified_ico.png" width="12">`; }

        el.innerHTML = `<b style="color:${c}">${author}${b}:</b> <span style="color:#ddd; margin-left:4px;">${text}</span>`;
        msgBox.appendChild(el);
        if (msgBox.childNodes.length > 80) msgBox.removeChild(msgBox.firstChild);
    }

    // --- 5. LANCEUR DU SYSTÈME (BOOT) ---
    async function bootSequence() {
        loginBox.style.display = 'none';
        loader.style.display = 'flex';

        updateLoader(25, "Security Check...");
        const { data: banned } = await supabaseClient.from('ban').select('*').eq('m13_id', m13Id).maybeSingle();
        if (banned) { document.body.innerHTML = "<h1 style='color:red;text-align:center;margin-top:100px;'>ACCESS DENIED</h1>"; return; }

        updateLoader(60, "Syncing Databases...");
        if (await checkUpdate()) return;

        updateLoader(90, "Finalizing UI...");
        await fetchMessages(true);

        updateLoader(100, "System Ready");
        setTimeout(() => {
            loader.style.opacity = "0";
            loader.style.transition = "opacity 0.6s";
            setTimeout(() => { 
                loader.style.display = 'none'; 
                chatBox.style.display = 'block'; 
                userInput.focus();
            }, 600);
        }, 300);

        setInterval(() => { checkUpdate(); fetchMessages(); }, 2000);
    }

    // --- 6. ÉVÈNEMENTS INTERFACE ---
    loginBtn.addEventListener('click', () => {
        const u = document.getElementById('username').value.trim();
        const p = document.getElementById('password').value;
        if (!u) return;

        if (u.toLowerCase() === 'siroxtag' && p === 'SM13') monPseudo = "Siroxtag";
        else if (u.toLowerCase() === 'samri' && p === 'Sally') monPseudo = "Samri";
        else monPseudo = u;

        localStorage.setItem('m13_pseudo', monPseudo);
        bootSequence();
    });

    userInput.addEventListener('keydown', async (e) => {
        lastActivity = Date.now();
        if (e.key === 'Enter' && userInput.value.trim()) {
            const val = userInput.value.trim();
            userInput.value = "";
            if (val.startsWith('/')) { await executeAdminCommand(val); return; }
            await supabaseClient.from('messages_m13').insert([{ pseudo: monPseudo, message: val }]);
        }
    });

    if (monPseudo) bootSequence();
});

// INJECTION DES STYLES OMEGA
const styleOmega = document.createElement('style');
styleOmega.innerHTML = `
    @keyframes slideIn { from { opacity:0; transform:translateX(-5px); } to { opacity:1; transform:translateX(0); } }
    #messages { height: 350px; overflow-y: auto; padding: 10px; background: rgba(255,255,255,0.01); }
    #messages::-webkit-scrollbar { width: 3px; }
    #messages::-webkit-scrollbar-thumb { background: #222; border-radius: 5px; }
    .status-dot { width:8px; height:8px; border-radius:50%; display:inline-block; margin-right:5px; background:#0f0; }
`;
document.head.appendChild(styleOmega);
/** FIN DU SCRIPT - PROJECT M13 SUPREME **/