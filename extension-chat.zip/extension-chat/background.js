// On force le chargement du SDK local
try {
    importScripts('supabase.js');
} catch (e) {
    console.error("Erreur de chargement du script Supabase :", e);
}

const SUPABASE_URL = "https://nlgzunlagcdgsbkzeiin.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5sZ3p1bmxhZ2NkZ3Nia3plaWluIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc2MDQyNzksImV4cCI6MjA4MzE4MDI3OX0.4sSfmztjJJkfHaIOBOK6Pv-27QWSpM2B-lxg0b3XC7U";

const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

// Écoute en arrière-plan
supabaseClient
  .channel('public:messages_m13')
  .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages_m13' }, payload => {
    
    // Envoi à la popup
    chrome.runtime.sendMessage({ type: "NEW_MESSAGE", data: payload.new }).catch(() => {});

    // Notification système
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon.png',
      title: `M13 - ${payload.new.pseudo}`,
      message: payload.new.message,
      priority: 2
    });
  })
  .subscribe();