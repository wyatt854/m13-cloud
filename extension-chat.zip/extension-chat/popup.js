const SUPABASE_URL = "https://nlgzunlagcdgsbkzeiin.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5sZ3p1bmxhZ2NkZ3Nia3plaWluIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc2MDQyNzksImV4cCI6MjA4MzE4MDI3OX0.4sSfmztjJJkfHaIOBOK6Pv-27QWSpM2B-lxg0b3XC7U";
const VERSION_ACTUELLE = 1.0; 

const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

document.addEventListener('DOMContentLoaded', () => {
    const loginBtn = document.getElementById('login-btn');
    const loginBox = document.getElementById('login-box');
    const chatBox = document.getElementById('chat-box');
    const userInput = document.getElementById('user-input');
    const msgBox = document.getElementById('messages');

    let monPseudo = localStorage.getItem('m13_pseudo');
    if (monPseudo) activerChat();

    loginBtn.addEventListener('click', () => {
        const u = document.getElementById('username').value.trim();
        const p = document.getElementById('password').value;
        if (!u) return alert("Pseudo requis");

        // Gestion des comptes spéciaux
        if (u.toLowerCase() === 'siroxtag' && p === 'SM13') {
            monPseudo = "Siroxtag";
        } else if (u.toLowerCase() === 'samri' && p === 'Sally') {
            monPseudo = "Samri";
        } else {
            monPseudo = u;
        }

        localStorage.setItem('m13_pseudo', monPseudo);
        activerChat();
    });

    async function activerChat() {
        loginBox.style.display = 'none';
        chatBox.style.display = 'block';

        // 1. Vérification Update via Supabase
        try {
            const { data } = await supabaseClient.from('update').select('version').single();
            if (data && data.version > VERSION_ACTUELLE) {
                const downloadUrl = `https://cloud.siroxtag.world/extension_${data.version}.zip`;
                
                document.body.innerHTML = `
                    <div style="color:white; background:#111; border:2px solid #00f; padding:20px; text-align:center; font-family:sans-serif; height:100vh; display:flex; flex-direction:column; justify-content:center; align-items:center;">
                        <h2 style="color:#0af; margin-bottom:10px;">MISE À JOUR REQUISE</h2>
                        <p style="margin-bottom:20px;">Une version plus récente (V${data.version}) est disponible sur le Cloud.</p>
                        <a href="${downloadUrl}" target="_blank" style="background:#00f; color:white; padding:12px 25px; text-decoration:none; border-radius:5px; font-weight:bold; border: 1px solid #0af; box-shadow: 0 0 10px #0af;">
                            INSTALLER LA V${data.version}
                        </a>
                        <p style="font-size:11px; color:#555; margin-top:20px;">Status: Obsolète (V${VERSION_ACTUELLE})</p>
                    </div>`;
                return;
            }
        } catch (e) { console.warn("Update check bypass"); }

        // 2. Historique des messages
        const { data: msgs } = await supabaseClient.from('messages_m13').select('*').order('created_at', { ascending: false }).limit(25);
        if (msgs) {
            msgBox.innerHTML = '';
            msgs.reverse().forEach(m => afficherMessage(m.pseudo, m.message));
        }

        // 3. Écoute temps réel
        chrome.runtime.onMessage.addListener((request) => {
            if (request.type === "NEW_MESSAGE") {
                afficherMessage(request.data.pseudo, request.data.message);
            }
        });
    }

    userInput.addEventListener('keypress', async (e) => {
        if (e.key === 'Enter' && userInput.value.trim() !== "") {
            const m = userInput.value.trim();
            userInput.value = "";
            await supabaseClient.from('messages_m13').insert([{ pseudo: monPseudo, message: m }]);
        }
    });

    function afficherMessage(p, m) {
        const d = document.createElement('div');
        d.className = "msg";
        
        let badges = "";
        const isSiroxtag = p.toLowerCase() === 'siroxtag';
        const isSamri = p.toLowerCase() === 'samri';

        if (isSiroxtag) {
            badges = `
                <img src="verified_ico.png" class="badge-anim" title="Vérifié" width="14" style="margin-left:5px;">
                <img src="crown_ico.png" class="badge-anim" title="Créateur Officiel" width="14" style="margin-left:3px;">`;
        } else if (isSamri) {
            // Badge spécial pour Samri (version V2)
            badges = `<img src="verified_ico.png" class="badge-anim" title="Admin Système" width="14" style="margin-left:5px; filter: hue-rotate(180deg) brightness(1.5);">`;
        }

        const color = isSiroxtag ? "#0f0" : (isSamri ? "#0af" : "#aaa");
        d.innerHTML = `<b style="color:${color}">${p}${badges}:</b> <span style="color:#eee">${m}</span>`;
        
        msgBox.appendChild(d);
        msgBox.scrollTop = msgBox.scrollHeight;
    }
});